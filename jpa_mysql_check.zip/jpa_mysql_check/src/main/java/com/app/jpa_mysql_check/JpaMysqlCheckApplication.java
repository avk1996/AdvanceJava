package com.app.jpa_mysql_check;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaMysqlCheckApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaMysqlCheckApplication.class, args);
	}

}
