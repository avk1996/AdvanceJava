package com.app.jpa_mysql_check;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaMysqlCheckApplicationTests {

	@Test
	void contextLoads() {
	}

}
