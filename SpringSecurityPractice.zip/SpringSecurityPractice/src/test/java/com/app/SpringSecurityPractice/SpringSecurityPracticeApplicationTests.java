package com.app.SpringSecurityPractice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
